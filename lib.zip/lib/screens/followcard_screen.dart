import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:instragram_app/screens/profile_screen.dart';
import 'package:instragram_app/utils/colors.dart';

class FollowCard extends StatefulWidget {
  final snap;

  const FollowCard({
    Key? key,
    required this.snap,
  }) : super(key: key);

  @override
  State<FollowCard> createState() => _FollowCardState();
}

class _FollowCardState extends State<FollowCard> {
  List<dynamic> followList = [];

  getdata() async {
    List<dynamic> followers = [];

    final currentUserSnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .get();

    List<String> followIds =
        List.from(currentUserSnapshot.data()!['following']);

    for (int i = 0; i < followIds.length; i++) {
      var followId = followIds[i];
      var data = await FirebaseFirestore.instance
          .collection('users')
          .doc(followId)
          .get();

      followers.add(data);
    }
    setState(() => followList = followers);
  }

  @override
  void initState() {
    super.initState();
    getdata();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const NeverScrollableScrollPhysics(),
      child: ListView.builder(
          shrinkWrap: true,
          itemCount: followList.length,
          itemBuilder: (context, index) {
            var followerItem = followList[index];
            print('photoUrl');

            return Container(
              height: 70,
              width: double.infinity,
              color: mobileBackgroundColor,
              child: Card(
                child: Column(children: [
                  //Header
                  Container(
                    height: 40,
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(
                      vertical: 4,
                      horizontal: 16,
                    ).copyWith(right: 0),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 16,
                          backgroundImage: NetworkImage(
                            followerItem['photoUrl'],
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => ProfileScreen(
                                                uid: followerItem['uid'])));
                                  },
                                  child: Text(
                                    followerItem['username'],
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                ]),
              ),
            );
          }),
    );
  }
}
