import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:instragram_app/resources/firestore_methods.dart';
import 'package:instragram_app/utils/colors.dart';
import 'package:instragram_app/utils/utils.dart';
import 'package:instragram_app/widgets/follow_button.dart';
import 'package:instragram_app/widgets/text_field_input.dart';

int followerss = 0;
int followingg = 0;

class SearchScreen extends StatefulWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController searchController = TextEditingController();
  bool isShowUsers = false;
  bool isFollowing = false;

  getData() async {
    try {
      var userSnap =
          await FirebaseFirestore.instance.collection('users').doc().get();

      followerss = userSnap.data()!['followers'].length;
      followingg = userSnap.data()!['following'].length;
      isFollowing = userSnap
          .data()!['followers']
          .contains(FirebaseAuth.instance.currentUser!.uid);
      setState(() {});
    } catch (e) {
      showSnackBar(
        context,
        e.toString(),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: mobileBackgroundColor,
          title: Form(
            child: TextFieldInput(
              hintText: 'Search for a user...',
              onFieldSubmitted: (String _) {
                setState(() {
                  isShowUsers = true;
                });
              },
              textInputType: TextInputType.emailAddress,
              textEditingController: searchController,
            ),
          ),
        ),
        body: FutureBuilder(
          future: FirebaseFirestore.instance.collection('users').get(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            } else if (snapshot.hasError) {
              return const Center(
                child: Text('Error loading data'),
              );
            }

            final users = snapshot.data!.docs;

            return ListView.builder(
              itemCount: users.length,
              itemBuilder: (context, index) {
                final userData = users[index].data();
                final targetUserId = userData['uid'] as String;
                return ListTile(
                  contentPadding:
                      const EdgeInsets.only(top: 05, left: 10, right: 10),
                  leading: CachedNetworkImage(
                    imageUrl: userData['photoUrl'] ?? '',
                    imageBuilder: (context, imageProvider) => CircleAvatar(
                      backgroundImage: imageProvider,
                      radius: 25,
                    ),
                    placeholder: (context, url) =>
                        const CircularProgressIndicator(),
                    errorWidget: (context, url, error) => const CircleAvatar(
                      backgroundImage: NetworkImage(
                          'https://img.freepik.com/free-photo/young-bearded-man-with-striped-shirt_273609-5677.jpg'),
                      radius: 25,
                    ),
                  ),
                  title: Text(
                    userData['username'] ?? '',
                  ),
                  trailing: FollowButton(
                    text: isFollowing ? 'Unfollow' : 'Follow',
                    backgroundColor: isFollowing ? Colors.white : Colors.blue,
                    textColor: isFollowing ? Colors.black : Colors.white,
                    borderColor: isFollowing ? Colors.grey : Colors.blue,
                    function: () async {
                      if (isFollowing) {
                        await FireStoreMethods().unfollowUser(
                          FirebaseAuth.instance.currentUser!.uid,
                          targetUserId,
                        );
                      } else {
                        await FireStoreMethods().followUser(
                          FirebaseAuth.instance.currentUser!.uid,
                          targetUserId,
                        );
                      }

                      setState(() {
                        isFollowing = !isFollowing;
                        if (isFollowing) {
                          followerss++;
                        } else {
                          followerss--;
                        }
                      });
                    },
                  ),
                  // isFollowing == false
                  //     ? FollowButton(
                  //         text: 'Follow',
                  //         backgroundColor: Colors.blue,
                  //         textColor: Colors.white,
                  //         borderColor: Colors.blue,
                  //         function: () async {
                  //           await FireStoreMethods().unfollowUser(
                  //             FirebaseAuth.instance.currentUser!.uid,
                  //             targetUserId,
                  //           );

                  //           setState(() {
                  //             isFollowing = true;
                  //             followerss++;
                  //           });
                  //         },
                  //       )
                  //     : FollowButton(
                  //         text: 'Unfollow',
                  //         backgroundColor: Colors.white,
                  //         textColor: Colors.black,
                  //         borderColor: Colors.grey,
                  //         function: () async {
                  //           await FireStoreMethods().unfollowUser(
                  //             FirebaseAuth.instance.currentUser!.uid,
                  //             targetUserId,
                  //           );

                  //           setState(() {
                  //             isFollowing = false;
                  //             followerss--;
                  //           });
                  //         },
                  //       ),
                );
              },
            );
          },
        )

        // isShowUsers
        //     ? FutureBuilder(
        //         future: FirebaseFirestore.instance
        //             .collection('users')
        //             .where(
        //               'username',
        //               isGreaterThanOrEqualTo: searchController.text,
        //             )
        //             .get(),
        //         builder: (context, snapshot) {
        //           if (!snapshot.hasData) {
        //             return const Center(
        //               child: CircularProgressIndicator(),
        //             );
        //           }
        //           return ListView.builder(
        //             itemCount: (snapshot.data! as dynamic).docs.length,
        //             itemBuilder: (context, index) {
        //               return InkWell(
        //                 onTap: () => Navigator.of(context).push(
        //                   MaterialPageRoute(
        //                     builder: (context) => ProfileScreen(
        //                       uid: (snapshot.data! as dynamic).docs[index]['uid'],
        //                     ),
        //                   ),
        //                 ),
        //                 child: ListTile(
        //                   leading: CircleAvatar(
        //                     backgroundImage: NetworkImage(
        //                       (snapshot.data! as dynamic).docs[index]['photoUrl'],
        //                     ),
        //                     radius: 16,
        //                   ),
        //                   title: Text(
        //                     (snapshot.data! as dynamic).docs[index]['username'],
        //                   ),
        //                 ),
        //               );
        //             },
        //           );
        //         },
        //       )
        //     : FutureBuilder(
        //         future: FirebaseFirestore.instance
        //             .collection('posts')
        //             .orderBy('datePublished')
        //             .get(),
        //         builder: (context, snapshot) {
        //           if (!snapshot.hasData) {
        //             return const Center(
        //               child: CircularProgressIndicator(),
        //             );
        //           }

        //           return Padding(
        //             padding: const EdgeInsets.only(top: 5),
        //             child: MasonryGridView.count(
        //               crossAxisCount: 3,
        //               itemCount: (snapshot.data! as dynamic).docs.length,
        //               itemBuilder: (context, index) => Image.network(
        //                 (snapshot.data! as dynamic).docs[index]['postUrl'],
        //                 fit: BoxFit.cover,
        //               ),
        //               mainAxisSpacing: 2.0,
        //               crossAxisSpacing: 2.0,
        //             ),
        //           );
        //         },
        //       ),
        );
  }
}
